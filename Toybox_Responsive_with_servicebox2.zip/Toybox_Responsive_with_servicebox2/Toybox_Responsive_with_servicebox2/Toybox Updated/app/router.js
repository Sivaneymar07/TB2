app.config(['$routeProvider',function($routeProvider) {

	$routeProvider
		.when('/',{
			templateUrl : 'partials/boxPage.html'
			
 		})
 		.when('/home',{
			templateUrl : 'partials/home.html'
			
 		})
		.when('/micro',{
			templateUrl : 'partials/microsite.html'
			
 		})
 		.when('/temp',{
			templateUrl : 'template/micrositeTemp.html',
			controller : 'micrositeController'
			
 		})
		.when('/channel',{
			 templateUrl :'partials/chooseChannel.html'
		})

		.when('/natureOfWebsite',{
			templateUrl  :'partials/nature.html'
		})

		.when('/designLayout',{
			templateUrl  :'partials/designlayout.html'
		})
    
    	.when('/toybox',{
			templateUrl  :'partials/toybox.html',
			controller : 'toyboxController'
		})
    	.when('/ready',{
			templateUrl  :'partials/readyPage.html',
			controller : 'readyPageController'
			
		})
		.when('/servicebox_1',{
			templateUrl : 'partials/servicebox_1.html'
			
 		})
 		.when('/servicebox_2',{
			templateUrl : 'partials/servicebox_2.html'
			
 		})
 		.when('/servicebox_3',{
			templateUrl : 'partials/servicebox_3.html'
			
 		})
		.when('/servicebox_4',{
			templateUrl  :'partials/servicebox_4.html'
			
		})
		.when('/servicebox_5',{
			templateUrl  :'partials/servicebox_5.html'
			
		})
		.when('/Chatbot',{
			templateUrl  :'partials/chatbot.html'
		})
		.otherwise({
			redirectTo : '/',
			controller  : ''
		})
}]);