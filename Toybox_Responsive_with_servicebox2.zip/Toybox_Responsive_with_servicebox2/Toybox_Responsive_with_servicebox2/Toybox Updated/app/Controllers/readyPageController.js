// readyPage controller
app.controller('readyPageController', function($scope, $rootScope, $location, $anchorScroll) {
    $scope.hostpage = function() {
        $rootScope.hostClicked = true;
        localStorage.setItem('hostClick', true);
        
    }
});
