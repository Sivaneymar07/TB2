var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'ngStorage']);

// Back_button directive
app.directive('backButton', function() {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            element.bind('click', goBack);

            function goBack() {
                history.back();
                scope.$apply();
            }
        }
    }
});

app.directive('tempSection', function() {
    return {
        restrict: 'E',
        link: function(scope, element, attrs) {
            scope.getContentUrl = function() {
                return 'template/' + attrs.ver + '.html';
            }
        },
        templateUrl: 'template/micrositeTemp.html',
        controller: 'micrositeController',
        scope: {
            save: '&',
            plus: '&',
            disableEditor: '&',
            chooseTemplate: '&',
            titleName: '='
        }
    }
});
app.service('themeService',function(){

})